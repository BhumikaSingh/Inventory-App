package com.example.sbhumika274.myinventory;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.sbhumika274.myinventory.data.MobileContract;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

/**
 * Created by hemezh on 22/10/16.
 */

public class EditQuantityActivity extends Activity {

    private Uri mCurrentMobileUri;
    private String mType;
    private int mCurrentQuantity;
    private int mProductsReceived;
    private EditText mEdit;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);

        setContentView(R.layout.activity_edit_quantity);

        mEdit = (EditText) findViewById(R.id.quantity);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();

        mCurrentMobileUri = intent.getData();

        mType = extras.getString("type");
        mCurrentQuantity = Integer.parseInt(extras.getString("currentQuantity"));

        final Button button = (Button) findViewById(R.id.save_button);
        final EditQuantityActivity that = this;
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                mProductsReceived = Integer.parseInt(mEdit.getText().toString());

                Log.d("asjldasd", "" + mCurrentQuantity);
                if (mType.equals(String.valueOf(R.string.action_trackASale))) {
                    mCurrentQuantity = mCurrentQuantity - mProductsReceived;
                    if (mCurrentQuantity >= 0) {
                        saveMobile();
                    } else {
                        Toast.makeText(that, getString(R.string.editor_insert_mobile_failed), Toast.LENGTH_SHORT).show();
                    }
                } else if (mType.equals(String.valueOf(R.string.action_receiveShipment))) {
                    mCurrentQuantity = mCurrentQuantity + mProductsReceived;
                    saveMobile();
                    Log.v("EditText", String.valueOf(mCurrentQuantity));
                }
                finish();                  
            }
        });

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    /**
     * Get user input from editor and save mobile into database.
     */
    private void saveMobile() {

        // Create a ContentValues object where column names are the keys,
        // and mobile attributes from the editor are the values.
        ContentValues values = new ContentValues();
        values.put(MobileContract.MobileEntry.COlUMN_MOBILE_QUANTITY, mCurrentQuantity);
        // If the price is not provided by the user, don't try to parse the string into an
        // integer value. Use 0 by default.
        // Otherwise this is an EXISTING mobile, so update the mobile with content URI: mCurrent MobileUri
        // and pass in the new ContentValues. Pass in null for the selection and selection args
        // because mCurrent MobileUri will already identify the correct row in the database that
        // we want to modify.
        int rowsAffected = getContentResolver().update(mCurrentMobileUri, values, null, null);

        // Show a toast message depending on whether or not the update was successful.
        if (rowsAffected == 0) {
            // If no rows were affected, then there was an error with the update.
            Toast.makeText(this, getString(R.string.editor_update_mobile_failed),
                    Toast.LENGTH_SHORT).show();
        } else {
            // Otherwise, the update was successful and we can display a toast.
            Toast.makeText(this, getString(R.string.editor_update_mobile_successful),
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "EditQuantity Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.example.sbhumika274.myinventory/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "EditQuantity Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.example.sbhumika274.myinventory/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }
}

