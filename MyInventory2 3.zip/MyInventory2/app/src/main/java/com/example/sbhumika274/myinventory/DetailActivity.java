/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.sbhumika274.myinventory;

import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.sbhumika274.myinventory.data.MobileContract;

import java.io.IOException;
import java.io.InputStream;

/**
 * Allows user to create a new mobile or edit an existing one.
 */
public class DetailActivity extends AppCompatActivity implements
        LoaderManager.LoaderCallbacks<Cursor> {
    /**
     * Identifier for the mobile data loader
     */
    private static final int EXISTING_MOBILE_LOADER = 0;

    /**
     * Content URI for the existing mobile (null if it's a new mobile)
     */
    private Uri mCurrentMobileUri;

    /**
     * EditText field to enter the mobile's name
     */
    private TextView mCompanyTextView;

    /**
     * EditText field to enter the mobile's company
     */
    private TextView mMobileTextView;

    /**
     * EditText field to enter the mobile's price
     */
    private TextView mSupplierTextView;

    /**
     * EditText field to enter the mobile's company
     */
    private TextView mPriceTextView;

    /**
     * EditText field to enter the mobile's company
     */
    private TextView mQuantityTextView;

    //**EditText field to enter the supplier's email_id */
    private TextView mSupplierEmailTextView;

    //** EditText field to enter the product image

    private ImageView mProductImageView;
    /**
     * Companyof the mobile. The possible valid values are in the MobileContract.java file:
     * {@link MobileContract# COMANY_NOkIA}, {@link MobileContract #COMPANY_APPLE}, or
     * {@link MobileContract# COMPANY_GOOGLE}.
     */
    private int mCompany = MobileContract.MobileEntry.COMPANY_NOKIA;

    /**
     * Boolean flag that keeps track of whether the mobile has been edited (true) or not (false)
     */
    private boolean mMobileHasChanged = false;

    /**
     * OnTouchListener that listens for any user touches on a View, implying that they are modifying
     * the view, and we change the mMobileHasChanged boolean to true.
     */
    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            mMobileHasChanged = true;
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // Examine the intent that was used to launch this activity,
        // in order to figure out if we're creating a new mobile or editing an existing one.
        Intent intent = getIntent();
        mCurrentMobileUri = intent.getData();

        // If the intent DOES NOT contain a mobile content URI, then we know that we are
        // creating a new mobile.
        if (mCurrentMobileUri == null) {
            // This is a new mobile, so change the app bar to say "Add a Mobile"
            setTitle(getString(R.string.editor_activity_title_new_mobile));

            // Invalidate the options menu, so the "Delete" menu option can be hidden.
            // (It doesn't make sense to delete a mobile that hasn't been created yet.)
            invalidateOptionsMenu();
        } else {
            // Otherwise this is an existing mobile, so change app bar to say "Edit Mobile"
            setTitle(getString(R.string.editor_activity_title_edit_mobile));

            // Initialize a loader to read the mobile data from the database
            // and display the current values in the editor
            getLoaderManager().initLoader(EXISTING_MOBILE_LOADER, null, this);
        }

        // Find all relevant views that we will need to read user input from
        mCompanyTextView = (TextView) findViewById(R.id.company_name);
        mMobileTextView = (TextView) findViewById(R.id.mobile_name);
        mSupplierTextView = (TextView) findViewById(R.id.supplier);
        mPriceTextView = (TextView) findViewById(R.id.price);
        mQuantityTextView = (TextView) findViewById(R.id.quantity);
        mSupplierEmailTextView = (TextView) findViewById(R.id.email);
        mProductImageView = (ImageView) findViewById(R.id.product_image);
    }

    private void setupSpinner() {
        // Create adapter for spinner. The list options are from the String array it will use
        // the spinner will use the default layout
        ArrayAdapter companySpinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.array_company_options, android.R.layout.simple_spinner_item);

        // Specify dropdown layout style - simple list view with 1 item per line
        companySpinnerAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
    }

    private void trackASale() {
        // Create new intent to go to {@link EditorActivity}
        Intent intent = new Intent(DetailActivity.this, EditQuantityActivity.class);

        // Set the URI on the data field of the intent
        intent.setData(mCurrentMobileUri);

        Bundle extras = new Bundle();
        extras.putString("type", String.valueOf(R.string.action_trackASale));
        extras.putString("currentQuantity", (String) mQuantityTextView.getText());
        intent.putExtras(extras);
        // Launch the {@link EditorActivity} to display the data for the current mobile.
        startActivity(intent);

    }

    private void receiveShipment() {
        // Create new intent to go to {@link EditorActivity}
        Intent intent = new Intent(DetailActivity.this, EditQuantityActivity.class);

        // Set the URI on the data field of the intent
        intent.setData(mCurrentMobileUri);

        Bundle extras = new Bundle();
        extras.putString("type", String.valueOf(R.string.action_receiveShipment));
        extras.putString("currentQuantity", (String) mQuantityTextView.getText());
        intent.putExtras(extras);
        // Launch the {@link EditorActivity} to display the data for the current mobile.
        startActivity(intent);
    }

    private void orderMore() {
        Intent sendIntent = new Intent(Intent.ACTION_VIEW);
        sendIntent.setType("plain/text");
        sendIntent.setData(Uri.parse((String) mSupplierEmailTextView.getText()));
        sendIntent.setClassName("com.google.android.gm", "com.google.android.gm.ComposeActivityGmail");
        sendIntent.putExtra(Intent.EXTRA_SUBJECT, "Order More");
        sendIntent.putExtra(Intent.EXTRA_TEXT, "hello. this is a message sent from my demo app :-)");
        startActivity(sendIntent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu options from the res/menu/menu_editor.xml file.
        // This adds menu items to the app bar.
        getMenuInflater().inflate(R.menu.menu_editor, menu);
        return true;
    }
    /**
     * This method is called after invalidateOptionsMenu(), so that the
     * menu can be updated (some menu items can be hidden or made visible).
     */
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        // If this is a new mobile, hide the "Delete" menu item.
        if (mCurrentMobileUri == null) {
            MenuItem menuItem = menu.findItem(R.id.action_delete);
            menuItem.setVisible(false);
        }
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // User clicked on a menu option in the app bar overflow menu
        switch (item.getItemId()) {
            // Respond to a click on the "Save" menu option
            case R.id.action_save:
                finish();
                return true;
            case R.id.action_orderMore:
                orderMore();
                return true;
            case R.id.action_receiveShipment:
                receiveShipment();
                return true;
            case R.id.action_trackASale:
                trackASale();
                return true;
            // Respond to a click on the "Delete" menu option
            case R.id.action_delete:
                // Pop up confirmation dialog for deletion
                showDeleteConfirmationDialog();
                return true;
            // Respond to a click on the "Up" arrow button in the app bar
            case android.R.id.home:
                // If the mobile hasn't changed, continue with navigating up to parent activity
                // which is the {@link CatalogActivity}.
                if (!mMobileHasChanged) {
                    NavUtils.navigateUpFromSameTask(DetailActivity.this);
                    return true;
                }
                // Otherwise if there are unsaved changes, setup a dialog to warn the user.
                // Create a click listener to handle the user confirming that
                // changes should be discarded.
                DialogInterface.OnClickListener discardButtonClickListener =
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // User clicked "Discard" button, navigate to parent activity.
                                NavUtils.navigateUpFromSameTask(DetailActivity.this);
                            }
                        };
                // Show a dialog that notifies the user they have unsaved changes
                showUnsavedChangesDialog(discardButtonClickListener);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * This method is called when the back button is pressed.
     */
    @Override
    public void onBackPressed() {
        // If the mobile hasn't changed, continue with handling back button press
        if (!mMobileHasChanged) {
            super.onBackPressed();
            return;
        }
        // Otherwise if there are unsaved changes, setup a dialog to warn the user.
        // Create a click listener to handle the user confirming that changes should be discarded.
        DialogInterface.OnClickListener discardButtonClickListener =
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // User clicked "Discard" button, close the current activity.
                        finish();
                    }
                };

        // Show dialog that there are unsaved changes
        showUnsavedChangesDialog(discardButtonClickListener);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
        // Since the editor shows all mobile attributes, define a projection that contains
        // all columns from the mobile table
        String[] projection = {
                MobileContract.MobileEntry._ID,
                MobileContract.MobileEntry.COLUMN_MOBILE_NAME,
                MobileContract.MobileEntry.COLUMN_MOBILE_SUPPLIER,
                MobileContract.MobileEntry.COlUMN_MOBILE_COMPANY,
                MobileContract.MobileEntry.COLUMN_MOBILE_PRICE,
                MobileContract.MobileEntry.COlUMN_MOBILE_QUANTITY,
                MobileContract.MobileEntry.COLUMN_SUPPLIER_EMAIL,
                MobileContract.MobileEntry.COLUMN_PRODUCT_IMAGE,
        };

        // This loader will execute the ContentProvider's query method on a background thread
        return new CursorLoader(this,   // Parent activity context
                mCurrentMobileUri,         // Query the content URI for the current mobile
                projection,             // Columns to include in the resulting Cursor
                null,                   // No selection clause
                null,                   // No selection arguments
                null);                  // Default sort order
     }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        // Bail early if the cursor is null or there is less than 1 row in the cursor
        if (cursor == null || cursor.getCount() < 1) {
            return;
        }

        // Proceed with moving to the first row of the cursor and reading data from it
        // (This should be the only row in the cursor)
        if (cursor.moveToFirst()) {
            // Find the columns of mobile attributes that we're interested in
            int nameColumnIndex = cursor.getColumnIndex(MobileContract.MobileEntry.COLUMN_MOBILE_NAME);
            int supplierColumnIndex = cursor.getColumnIndex(MobileContract.MobileEntry.COLUMN_MOBILE_SUPPLIER);
            int companyColumnIndex = cursor.getColumnIndex(MobileContract.MobileEntry.COlUMN_MOBILE_COMPANY);
            int priceColumnIndex = cursor.getColumnIndex(MobileContract.MobileEntry.COLUMN_MOBILE_PRICE);
            int quantityColumnIndex = cursor.getColumnIndex(MobileContract.MobileEntry.COlUMN_MOBILE_QUANTITY);
            int emailColumnIndex = cursor.getColumnIndex(MobileContract.MobileEntry.COLUMN_SUPPLIER_EMAIL);
            int imageColumnIndex = cursor.getColumnIndex(MobileContract.MobileEntry.COLUMN_PRODUCT_IMAGE);


            // Extract out the value from the Cursor for the given column index
            String name = cursor.getString(nameColumnIndex);
            String supplier = cursor.getString(supplierColumnIndex);
            int company = cursor.getInt(companyColumnIndex);
            int price = cursor.getInt(priceColumnIndex);
            int quantity = cursor.getInt(quantityColumnIndex);
            String email = cursor.getString(emailColumnIndex);
            String image = cursor.getString(imageColumnIndex);

            // Update the views on the screen with the values from the database
            mMobileTextView.setText(name);
            mSupplierTextView.setText(supplier);
            mPriceTextView.setText(Integer.toString(price));
            mQuantityTextView.setText(Integer.toString(quantity));

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), Uri.parse(image));


                mProductImageView.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }

            mSupplierEmailTextView.setText(email);

            // Company is a dropdown spinner, so map the constant value from the database
            // into one of the dropdown options (0 is nokia, 1 is google, 2 is apple.
            // Then call setSelection() so that option is displayed on screen as the current selection.
            switch (company) {
                case MobileContract.MobileEntry.COMPANY_APPLE:
                    mCompanyTextView.setText("Apple");
                    break;
                case MobileContract.MobileEntry.COMPANY_GOOGLE:
                    mCompanyTextView.setText("Google");
                    break;
                default:
                    mCompanyTextView.setText("Nokia");
                    break;
            }
        }
    }

    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        // If the loader is invalidated, clear out all the data from the input fields.
        mMobileTextView.setText("");
        mCompanyTextView.setText("");
        mPriceTextView.setText("");
        mSupplierTextView.setText("");
        mQuantityTextView.setText("");
    }
    /**
     * Show a dialog that warns the user there are unsaved changes that will be lost
     * if they continue leaving the editor.
     *
     * @param discardButtonClickListener is the click listener for what to do when
     *                                   the user confirms they want to discard their changes
     */
    private void showUnsavedChangesDialog(
            DialogInterface.OnClickListener discardButtonClickListener) {
        // Create an AlertDialog.Builder and set the message, and click listeners
        // for the postivie and negative buttons on the dialog.
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.unsaved_changes_dialog_msg);
        builder.setPositiveButton(R.string.discard, discardButtonClickListener);
        builder.setNegativeButton(R.string.keep_editing, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Keep editing" button, so dismiss the dialog
                // and continue editing the mobile.
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });

        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    /**
     * Prompt the user to confirm that they want to delete this mobile.
     */
    private void showDeleteConfirmationDialog() {
        // Create an AlertDialog.Builder and set the message, and click listeners
        // for the postivie and negative buttons on the dialog.
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.delete_dialog_msg);
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Delete" button, so delete the mobile.
                deleteMobile();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Cancel" button, so dismiss the dialog
                // and continue editing the mobile.
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    /**
     * Perform the deletion of the mobile in the database.
     */
    private void deleteMobile() {
        // Only perform the delete if this is an existing mobile.
        if (mCurrentMobileUri != null) {
            // Call the ContentResolver to delete the mobile at the given content URI.
            // Pass in null for the selection and selection args because the mCurrentMobileUri
            // content URI already identifies the mobile that we want.
            int rowsDeleted = getContentResolver().delete(mCurrentMobileUri, null, null);

            // Show a toast message depending on whether or not the delete was successful.
            if (rowsDeleted == 0) {
                // If no rows were deleted, then there was an error with the delete.
                Toast.makeText(this, getString(R.string.editor_delete_mobile_failed),
                        Toast.LENGTH_SHORT).show();
            } else {
                // Otherwise, the delete was successful and we can display a toast.
                Toast.makeText(this, getString(R.string.editor_delete_mobile_successful),
                        Toast.LENGTH_SHORT).show();
            }
        }
        // Close the activity
        finish();
    }
}