
package com.example.sbhumika274.myinventory;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sbhumika274.myinventory.data.MobileContract;

/**
 * {@link MobileCursorAdapter} is an adapter for a list or grid view
 * that uses a {@link Cursor} of mobile data as its data source. This adapter knows
 * how to create list items for each row of mobile data in the {@link Cursor}.
 */
public class MobileCursorAdapter extends CursorAdapter {

    /**
     * Constructs a new {@link MobileCursorAdapter}.
     *
     * @param context The context
     * @param c       The cursor from which to get the data.
     */
    public MobileCursorAdapter(Context context, Cursor c) {
        super(context, c, 0 /* flags */);
    }

    /**
     * Makes a new blank list item view. No data is set (or bound) to the views yet.
     *
     * @param context app context
     * @param cursor  The cursor from which to get the data. The cursor is already
     *                moved to the correct position.
     * @param parent  The parent to which the new view is attached to
     * @return the newly created list item view.
     */
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        // Inflate a list item view using the layout specified in list_item.xml
        return LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
    }

    /**
     * This method binds the mobile data (in the current row pointed to by cursor) to the given
     * list item layout. For example, the name for the current mobile can be set on the name TextView
     * in the list item layout.
     *
     * @param view    Existing view, returned earlier by newView() method
     * @param context app context
     * @param cursor  The cursor from which to get the data. The cursor is already moved to the
     *                correct row.
     */
    @Override
    public void bindView(View view, final Context context, final Cursor cursor) {
        // Find individual views that we want to modify in the list item layout
        TextView nameTextView = (TextView) view.findViewById(R.id.name);
        TextView quantityTextView = (TextView) view.findViewById(R.id.quantity);
        TextView priceTextView = (TextView) view.findViewById(R.id.price);
        Button trackASaleButton = (Button) view.findViewById(R.id.trackASale);

        // Find the columns of mobile attributes that we're interested in
        final int idColumnIndex = cursor.getColumnIndex(MobileContract.MobileEntry._ID);
        int nameColumnIndex = cursor.getColumnIndex(MobileContract.MobileEntry.COLUMN_MOBILE_NAME);
        int supplierColumnIndex = cursor.getColumnIndex(MobileContract.MobileEntry.COlUMN_MOBILE_QUANTITY);
        int priceColumnIndex = cursor.getColumnIndex(MobileContract.MobileEntry.COLUMN_MOBILE_PRICE);

        String mobileName = cursor.getString(nameColumnIndex);
        final int[] mobileQuantity = {cursor.getInt(supplierColumnIndex)};
        final int id = cursor.getInt(idColumnIndex);
        int mobilePrice = cursor.getInt(priceColumnIndex);

        trackASaleButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(mobileQuantity[0] < 1){
                    // No negative quantities should happen. Alternatively, you can also print out a message to the user so they know why the quantity isn't decreasing.
                    return;
                }

                mobileQuantity[0] = mobileQuantity[0] - 1;
                // Create a ContentValues object where column names are the keys,
                // and mobile attributes from the editor are the values.


                ContentValues values = new ContentValues();
                values.put(MobileContract.MobileEntry.COlUMN_MOBILE_QUANTITY, mobileQuantity[0]);
                // If the price is not provided by the user, don't try to parse the string into an
                // integer value. Use 0 by default.
                // Otherwise this is an EXISTING mobile, so update the mobile with content URI: mCurrent MobileUri
                // and pass in the new ContentValues. Pass in null for the selection and selection args
                // because mCurrent MobileUri will already identify the correct row in the database that
                // we want to modify.
                Uri currentUri = Uri.withAppendedPath(MobileContract.BASE_CONTENT_URI, MobileContract.MobileEntry.TABLE_NAME +"/"+ Integer.toString(id));
                int rowsAffected = context.getContentResolver().update(currentUri, values, null, null);

                // Show a toast message depending on whether or not the update was successful.
                if (rowsAffected == 0) {
                    // If no rows were affected, then there was an error with the update.
                    Toast.makeText(context, context.getString(R.string.editor_update_mobile_failed),
                            Toast.LENGTH_SHORT).show();
                } else {
                    // Otherwise, the update was successful and we can display a toast.
                    Toast.makeText(context, context.getString(R.string.editor_update_mobile_successful),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        Log.d("bhumika", " " + nameColumnIndex + supplierColumnIndex + priceColumnIndex);

        // Update the TextViews with the attributes for the current mobile
        nameTextView.setText(mobileName);
        quantityTextView.setText(Integer.toString(mobileQuantity[0]));
        priceTextView.setText(Integer.toString(mobilePrice));
    }
}